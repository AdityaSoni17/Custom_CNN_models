from keras._tf_keras.keras.regularizers import l2
from keras._tf_keras.keras.callbacks import EarlyStopping
from keras._tf_keras.keras.preprocessing.image import ImageDataGenerator
from keras._tf_keras.keras import layers, models
from keras._tf_keras.keras.callbacks import ReduceLROnPlateau
from PIL import Image
import os
import keras._tf_keras.keras

# Set maximum image pixel limit to avoid errors
Image.MAX_IMAGE_PIXELS = 208940600
from sklearn.utils import class_weight

# Define image dimensions
img_width, img_height = 224, 224

# Function to resize images
def resize_images(directory, target_size=(224, 224)):
    for filename in os.listdir(directory):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            img_path = os.path.join(directory, filename)
            img = Image.open(img_path)
            img = img.resize(target_size)
            img.save(img_path)


# Resize images in directories
resize_images('Dataset/training_data/feet')
resize_images('Dataset/testing_data/feet')

# Data augmentation
train_datagen = ImageDataGenerator(
    rescale=1.0 / 255,
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest'
)

test_datagen = ImageDataGenerator(rescale=1.0 / 255)

train_generator = train_datagen.flow_from_directory(
    '/Users/aditya/Downloads/Work/FeetFinder/Dataset/training_data',
    target_size=(img_height, img_width),
    batch_size=32,
    class_mode='binary'
)

test_generator = test_datagen.flow_from_directory(
    '/Users/aditya/Downloads/Work/FeetFinder/Dataset/testing_data',
    target_size=(img_height, img_width),
    batch_size=32,
    class_mode='binary'
)

# Calculate class weights
y_train = []  # Collect the labels
for _, labels in train_generator:
    print(_,labels)
    y_train.extend(labels)

class_weights = class_weight.compute_class_weight('balanced', classes=[0, 1], y=y_train)
class_weights = {0: class_weights[0], 1: class_weights[1]}

# Build the custom CNN model
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation='relu', input_shape=(img_height, img_width, 3)),
    layers.BatchNormalization(),
    layers.MaxPooling2D(2, 2),
    layers.Dropout(0.25),

    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.BatchNormalization(),
    layers.MaxPooling2D(2, 2),
    layers.Dropout(0.25),

    layers.Conv2D(128, (3, 3), activation='relu'),
    layers.BatchNormalization(),
    layers.MaxPooling2D(2, 2),
    layers.Dropout(0.5),

    layers.Flatten(),
    layers.Dense(256, activation='relu', kernel_regularizer=l2(0.001)),
    layers.BatchNormalization(),
    layers.Dropout(0.5),

    layers.Dense(1, activation='sigmoid')
])

# Compile the model
model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.0001),
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Callbacks
early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6)

# Train the model with class weights
model.fit(train_generator, epochs=30, validation_data=test_generator,
          callbacks=[early_stopping, reduce_lr],
          class_weight=class_weights)

# Evaluate the model
test_loss, test_accuracy = model.evaluate(test_generator)
print(f'Test accuracy: {test_accuracy:.2f}')

# Save the model
model.save('trained_model.h5')